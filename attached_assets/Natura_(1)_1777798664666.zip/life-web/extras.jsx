/* global React */
const { useEffect, useState } = React;

const { Bee, Bird, Flower, Frog, Mushroom, Sun, Tree, Cloud, Sparkle, TabBar } = window;

const PAPER_BG = "#fdf6e3";
const INK = "#1a1a1a";
const SKY = "#a8d8f0";
const GRASS = "#7fc77f";
const SUN_C = "#ffd24a";
const RED = "#e25555";
const PINK = "#f5a3c7";
const PURPLE = "#a78bd9";
const ORANGE = "#f08a3a";
const BLUE = "#5b8def";

const handFont = `"Caveat", "Marker Felt", cursive`;
const labelFont = `"Patrick Hand", "Marker Felt", cursive`;

const paperBgStyle = {
  background: `
    radial-gradient(circle at 20% 30%, rgba(180,140,100,0.07) 1px, transparent 1px),
    radial-gradient(circle at 70% 60%, rgba(180,140,100,0.06) 1px, transparent 1px),
    ${PAPER_BG}`,
  backgroundSize: "23px 23px, 31px 31px, auto",
};

function wobble(x1, y1, x2, y2, intensity = 2, segments = 8, seed = 0) {
  const dx = x2 - x1, dy = y2 - y1;
  let d = `M ${x1} ${y1}`;
  for (let i = 1; i <= segments; i++) {
    const t = i / segments;
    const px = x1 + dx * t, py = y1 + dy * t;
    const r = Math.sin((seed + i) * 1.7) * intensity + Math.cos((seed + i) * 2.3) * intensity * 0.6;
    const nx = -dy / Math.hypot(dx, dy), ny = dx / Math.hypot(dx, dy);
    d += ` L ${(px + nx * r).toFixed(1)} ${(py + ny * r).toFixed(1)}`;
  }
  return d;
}
function wobbleRect(x, y, w, h, intensity = 1.8, seed = 1) {
  const seg = 6;
  let d = `M ${x} ${y}`;
  const sides = [[x, y, x + w, y], [x + w, y, x + w, y + h], [x + w, y + h, x, y + h], [x, y + h, x, y]];
  sides.forEach(([x1, y1, x2, y2], si) => {
    for (let i = 1; i <= seg; i++) {
      const t = i / seg;
      const px = x1 + (x2 - x1) * t, py = y1 + (y2 - y1) * t;
      const r = Math.sin((seed + si * 7 + i) * 1.7) * intensity;
      d += ` L ${(px + r).toFixed(1)} ${(py + r * 0.7).toFixed(1)}`;
    }
  });
  return d + " Z";
}

function CrayonUnderline({ width = 120, color = SUN_C }) {
  return (
    <svg width={width} height="10" style={{ display: "block", marginTop: -2 }}>
      <path d={wobble(2, 5, width - 2, 6, 2, 10, 4)} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}

function useTime() {
  const [t, setT] = useState(0);
  useEffect(() => {
    let raf, start = performance.now();
    const tick = (now) => { setT((now - start) / 1000); raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
  return t;
}

// ===========================================================
// REALISTIC EARTH — satellite-style globe with proper continents
// ===========================================================
function LiveEarth({ size = 280 }) {
  const t = useTime();
  const rot = (t * 6) % 360; // continuous rotation

  return (
    <svg width={size} height={size} viewBox="0 0 320 320" style={{ overflow: "visible" }}>
      <defs>
        {/* deep space glow */}
        <radialGradient id="atmGlow" cx="50%" cy="50%" r="50%">
          <stop offset="78%" stopColor="#7fb8e8" stopOpacity="0" />
          <stop offset="92%" stopColor="#7fb8e8" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#7fb8e8" stopOpacity="0" />
        </radialGradient>
        {/* ocean — deep to lighter blue */}
        <radialGradient id="oceanGrad" cx="35%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#4ba3d8" />
          <stop offset="60%" stopColor="#1f5f95" />
          <stop offset="100%" stopColor="#0a2a4a" />
        </radialGradient>
        {/* land — lush gradient */}
        <radialGradient id="landGrad" cx="40%" cy="35%" r="80%">
          <stop offset="0%" stopColor="#7fb069" />
          <stop offset="50%" stopColor="#4f8a3c" />
          <stop offset="100%" stopColor="#2d5524" />
        </radialGradient>
        {/* shine highlight */}
        <radialGradient id="shineGrad" cx="32%" cy="28%" r="40%">
          <stop offset="0%" stopColor="white" stopOpacity="0.45" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
        {/* terminator (night side shadow) */}
        <radialGradient id="termGrad" cx="50%" cy="50%" r="50%">
          <stop offset="60%" stopColor="black" stopOpacity="0" />
          <stop offset="100%" stopColor="black" stopOpacity="0.55" />
        </radialGradient>
        {/* clip earth */}
        <clipPath id="earthClip">
          <circle cx="160" cy="160" r="120" />
        </clipPath>
      </defs>

      {/* atmosphere glow */}
      <circle cx="160" cy="160" r="150" fill="url(#atmGlow)" />
      <circle cx="160" cy="160" r="132" fill="none" stroke="#a8d8f0" strokeWidth="1.5" opacity="0.5" />

      {/* ocean sphere */}
      <circle cx="160" cy="160" r="120" fill="url(#oceanGrad)" />

      {/* CONTINENTS — clipped to globe; rotate to simulate spin */}
      <g clipPath="url(#earthClip)">
        <g transform={`translate(160 160)`}>
          {/* We render two staggered copies so as one rotates off-screen another comes on */}
          {[0, 360].map((offset, k) => (
            <g key={k} transform={`translate(${(((rot + offset) % 720) - 360) * 0.85} 0)`}>
              {/* North America */}
              <path d="M -200 -90 Q -220 -70 -210 -40 Q -200 -10 -180 -5 Q -160 0 -150 -20 Q -140 -45 -150 -65 Q -160 -85 -180 -92 Q -195 -95 -200 -90 Z"
                fill="url(#landGrad)" />
              {/* South America */}
              <path d="M -160 10 Q -170 25 -160 55 Q -155 80 -148 90 Q -142 92 -138 80 Q -135 50 -140 25 Q -148 8 -160 10 Z"
                fill="url(#landGrad)" />
              {/* Greenland */}
              <path d="M -120 -100 Q -128 -90 -122 -80 Q -112 -76 -108 -88 Q -110 -98 -120 -100 Z"
                fill="url(#landGrad)" />
              {/* Europe + Africa block */}
              <path d="M -50 -70 Q -60 -55 -52 -40 Q -45 -32 -32 -36 Q -22 -42 -20 -55 Q -22 -68 -34 -72 Q -45 -74 -50 -70 Z"
                fill="url(#landGrad)" />
              {/* Africa */}
              <path d="M -32 -28 Q -42 -10 -38 18 Q -32 50 -18 64 Q -8 68 0 60 Q 8 40 6 14 Q 2 -8 -10 -22 Q -22 -32 -32 -28 Z"
                fill="url(#landGrad)" />
              {/* Asia */}
              <path d="M -10 -82 Q 10 -88 50 -82 Q 90 -75 110 -55 Q 120 -38 105 -28 Q 80 -22 50 -28 Q 20 -32 0 -40 Q -12 -55 -10 -82 Z"
                fill="url(#landGrad)" />
              {/* India peninsula */}
              <path d="M 30 -28 Q 36 -10 42 0 Q 46 -8 48 -22 Q 44 -30 30 -28 Z" fill="url(#landGrad)" />
              {/* Southeast Asia / Indonesia bits */}
              <path d="M 80 -10 Q 95 -8 102 2 Q 96 8 86 6 Q 78 0 80 -10 Z" fill="url(#landGrad)" />
              <path d="M 110 12 Q 122 14 128 22 Q 122 28 112 24 Q 106 18 110 12 Z" fill="url(#landGrad)" />
              {/* Australia */}
              <path d="M 130 30 Q 110 32 102 48 Q 108 62 130 64 Q 152 60 158 46 Q 154 32 130 30 Z"
                fill="url(#landGrad)" />
              {/* small islands */}
              <ellipse cx="170" cy="20" rx="6" ry="3" fill="url(#landGrad)" />
              <ellipse cx="-90" cy="40" rx="4" ry="2" fill="url(#landGrad)" />

              {/* polar ice caps (don't move with rotation feel — but we let them) */}
              <ellipse cx="0" cy="-118" rx="180" ry="14" fill="#f0f8ff" opacity="0.7" />
              <ellipse cx="0" cy="118" rx="180" ry="12" fill="#f0f8ff" opacity="0.7" />
            </g>
          ))}
        </g>

        {/* swirling cloud layer — drifts opposite */}
        <g transform={`translate(160 160)`} opacity="0.55">
          <g transform={`translate(${-((rot * 0.6) % 360) * 0.85} 0)`}>
            {[0, 360].map((off, k) => (
              <g key={k} transform={`translate(${off - 180} 0)`}>
                <ellipse cx="-80" cy="-40" rx="34" ry="10" fill="white" />
                <ellipse cx="-30" cy="20" rx="44" ry="12" fill="white" />
                <ellipse cx="40" cy="-30" rx="38" ry="11" fill="white" />
                <ellipse cx="100" cy="40" rx="30" ry="9" fill="white" />
                <ellipse cx="20" cy="60" rx="36" ry="10" fill="white" />
                <ellipse cx="-110" cy="50" rx="22" ry="8" fill="white" />
                <ellipse cx="140" cy="-10" rx="24" ry="8" fill="white" />
              </g>
            ))}
          </g>
        </g>

        {/* terminator shadow (night side) */}
        <circle cx="160" cy="160" r="120" fill="url(#termGrad)" />
        {/* shine highlight */}
        <circle cx="160" cy="160" r="120" fill="url(#shineGrad)" />
      </g>

      {/* edge ring */}
      <circle cx="160" cy="160" r="120" fill="none" stroke="rgba(0,0,0,0.4)" strokeWidth="1" />
    </svg>
  );
}

// ===========================================================
// LIVE ANIMATED MAP
// ===========================================================
function LiveMap() {
  const t = useTime();
  const pulse = 120 + Math.sin(t * 1.5) * 6;
  const dashOffset = -(t * 12) % 100;
  const flow = Math.sin(t * 0.6) * 4;

  const critters = [
    { Comp: Bee, x: 95, y: 110, sz: 48, sx: 8, sy: 4, sp: 1.4, ph: 0 },
    { Comp: (p) => <Bird {...p} color={BLUE} />, x: 260, y: 100, sz: 48, sx: 6, sy: 3, sp: 1.1, ph: 1 },
    { Comp: Frog, x: 75, y: 220, sz: 46, sx: 2, sy: 6, sp: 1.6, ph: 2 },
    { Comp: (p) => <Flower {...p} petal={PINK} />, x: 255, y: 220, sz: 46, sx: 0, sy: 2, sp: 0.8, ph: 3 },
    { Comp: Mushroom, x: 155, y: 90, sz: 42, sx: 1, sy: 1, sp: 0.5, ph: 4 },
    { Comp: (p) => <Bird {...p} color={ORANGE} />, x: 295, y: 175, sz: 42, sx: 9, sy: 3, sp: 1.7, ph: 5 },
  ];

  return (
    <svg width="100%" viewBox="0 0 360 320" style={{ display: "block" }}>
      <defs>
        <pattern id="dither25m" width="4" height="4" patternUnits="userSpaceOnUse">
          <rect width="4" height="4" fill="transparent" />
          <rect x="0" y="0" width="2" height="2" fill="currentColor" />
        </pattern>
      </defs>
      <path d={wobbleRect(4, 4, 352, 312, 2, 11)} fill="#e8f4d6" stroke={INK} strokeWidth="3" />
      <g style={{ color: GRASS }}>
        <path d="M 40 60 Q 90 40 150 70 Q 210 100 280 80 Q 320 75 340 100 L 340 280 L 20 280 Z" fill="url(#dither25m)" opacity="0.7" />
      </g>
      <path d={wobble(20, 180 + flow, 340, 220 - flow, 5, 18, t * 2)} stroke={SKY} strokeWidth="14" fill="none" strokeLinecap="round" />
      <path d={wobble(20, 180 + flow, 340, 220 - flow, 5, 18, t * 2)} stroke={BLUE} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.5" />
      <g transform={`translate(60 100) rotate(${Math.sin(t) * 2} 25 40)`}><Tree size={50} color="#5fae5f" /></g>
      <g transform={`translate(240 70) rotate(${Math.sin(t * 1.2 + 1) * 2} 28 40)`}><Tree size={56} color={GRASS} /></g>
      <g transform={`translate(280 240) rotate(${Math.sin(t * 0.9 + 2) * 2} 24 40)`}><Tree size={48} color="#5fae5f" /></g>
      <g transform={`translate(40 240) rotate(${Math.sin(t * 1.1 + 3) * 2} 22 40)`}><Tree size={44} color={GRASS} /></g>

      <circle cx="180" cy="170" r={pulse} fill="none" stroke={RED} strokeWidth="2" strokeDasharray="6 4" strokeDashoffset={dashOffset} opacity="0.5" />
      <circle cx="180" cy="170" r={pulse} fill={RED} opacity="0.06" />
      <circle cx="180" cy="170" r={pulse - 8} fill="none" stroke={RED} strokeWidth="1" strokeDasharray="3 6" opacity="0.3" />

      <g transform={`translate(180 ${170 + Math.abs(Math.sin(t * 2.5)) * -4})`}>
        <ellipse cx="0" cy="14" rx="10" ry="3" fill="rgba(0,0,0,0.25)" />
        <path d="M -10 -16 Q -10 -28 0 -28 Q 10 -28 10 -16 Q 10 -8 0 6 Q -10 -8 -10 -16 Z" fill={RED} stroke={INK} strokeWidth="2.5" />
        <circle cx="0" cy="-16" r="4" fill="white" stroke={INK} strokeWidth="1.5" />
      </g>

      {critters.map((c, i) => {
        const dx = Math.sin(t * c.sp + c.ph) * c.sx;
        const dy = Math.cos(t * c.sp * 1.2 + c.ph) * c.sy;
        return (
          <g key={i} transform={`translate(${c.x + dx} ${c.y + dy})`}>
            <c.Comp size={c.sz} />
          </g>
        );
      })}

      <g transform="translate(20 30)">
        <text fontFamily={handFont} fontSize="14" fill={INK} transform="rotate(-3)">~ creatures spotted near you ~</text>
      </g>
    </svg>
  );
}

// ===========================================================
// ONBOARDING SHELL & CTA
// ===========================================================
function OBShell({ idx, total = 6, children, bg = paperBgStyle, skyTop = false }) {
  return (
    <div style={{ width: "100%", height: "100%", position: "relative", ...bg, overflow: "hidden" }}>
      {skyTop && <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "60%", background: `linear-gradient(180deg, #1a3050 0%, #4a78a8 50%, #c4e5f5 90%, #fdf6e3 100%)` }} />}
      <div style={{ position: "absolute", top: 56, left: 20, fontFamily: labelFont, fontSize: 13, color: skyTop ? "rgba(255,255,255,0.7)" : "#888", zIndex: 5 }}>skip ↻</div>
      <div style={{ position: "absolute", top: 56, right: 20, fontFamily: labelFont, fontSize: 13, color: skyTop ? "rgba(255,255,255,0.7)" : "#888", zIndex: 5 }}>{idx + 1} / {total}</div>
      <div style={{ position: "relative", padding: "100px 28px 40px", display: "flex", flexDirection: "column", alignItems: "center", height: "100%", boxSizing: "border-box" }}>
        {children}
      </div>
      <div style={{ position: "absolute", bottom: 30, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 8, zIndex: 5 }}>
        {Array.from({ length: total }).map((_, i) => (
          <svg key={i} width="14" height="14">
            <circle cx="7" cy="7" r="5" fill={i === idx ? INK : "transparent"} stroke={INK} strokeWidth="2" />
          </svg>
        ))}
      </div>
    </div>
  );
}

function CTAButton({ label, color = GRASS, w = 260, seed = 5 }) {
  return (
    <div style={{ position: "relative", width: w, height: 60 }}>
      <svg width={w} height="60" style={{ position: "absolute", inset: 0 }}>
        <path d={wobbleRect(4, 4, w - 8, 52, 1.8, seed)} fill={color} stroke={INK} strokeWidth="3" strokeLinejoin="round" />
        <path d={wobble(20, 14, w - 20, 14, 0.8, 8, seed + 4)} stroke="rgba(255,255,255,0.6)" strokeWidth="2" fill="none" />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: handFont, fontSize: 22, color: INK }}>{label}</div>
    </div>
  );
}

// SCREEN 1 — realistic earth, no animals
function OB1() {
  const t = useTime();
  // a few stars in the dark sky portion
  const stars = Array.from({ length: 16 }).map((_, i) => ({
    x: (i * 37) % 380 + 10,
    y: 30 + ((i * 23) % 120),
    sz: 1 + (i % 3) * 0.5,
    tw: 0.5 + Math.sin(t * 2 + i) * 0.5,
  }));
  return (
    <OBShell idx={0} skyTop>
      {/* stars */}
      <svg width="100%" height="200" style={{ position: "absolute", top: 0, left: 0, pointerEvents: "none" }} viewBox="0 0 390 200">
        {stars.map((s, i) => (
          <circle key={i} cx={s.x} cy={s.y} r={s.sz} fill="white" opacity={s.tw} />
        ))}
      </svg>

      <div style={{ marginTop: 20, position: "relative" }}>
        <LiveEarth size={300} />
      </div>

      <div style={{ marginTop: 30, textAlign: "center", position: "relative", zIndex: 2 }}>
        <h1 style={{ fontFamily: handFont, fontSize: 38, color: INK, margin: 0, lineHeight: 1, transform: "rotate(-1deg)" }}>Nature around you</h1>
        <h1 style={{ fontFamily: handFont, fontSize: 38, color: INK, margin: "4px 0 0", lineHeight: 1, transform: "rotate(1.5deg)" }}>
          is <span style={{ color: RED, textDecoration: "underline wavy" }}>changing</span>.
        </h1>
        <p style={{ fontFamily: labelFont, fontSize: 18, color: "#4a4a4a", margin: "14px 0 0" }}>Most people never notice it.</p>
      </div>
      <div style={{ marginTop: "auto", marginBottom: 70 }}>
        <CTAButton label="Show me my world →" />
      </div>
    </OBShell>
  );
}

// SCREEN 2 — location radar
function OB2() {
  const t = useTime();
  const pulse = 60 + Math.sin(t * 1.8) * 10;
  return (
    <OBShell idx={1}>
      <div style={{ marginTop: 30, textAlign: "center" }}>
        <h1 style={{ fontFamily: handFont, fontSize: 36, color: INK, lineHeight: 1, transform: "rotate(-0.5deg)" }}>Where are you?</h1>
        <CrayonUnderline width={180} color={RED} />
        <p style={{ fontFamily: labelFont, fontSize: 17, color: "#5a5a5a", margin: "14px 30px 0", lineHeight: 1.4 }}>
          We need a rough location to find the wild things sharing your neighborhood.
        </p>
      </div>
      <svg width="280" height="280" viewBox="0 0 280 280" style={{ marginTop: 30 }}>
        <defs>
          <pattern id="dither25o" width="4" height="4" patternUnits="userSpaceOnUse">
            <rect width="4" height="4" fill="transparent" />
            <rect x="0" y="0" width="2" height="2" fill="currentColor" />
          </pattern>
        </defs>
        {[0, 0.33, 0.66].map((offset, i) => {
          const r = 30 + (((t + offset * 2) % 2) / 2) * 100;
          const op = 1 - (((t + offset * 2) % 2) / 2);
          return <circle key={i} cx="140" cy="140" r={r} fill="none" stroke={RED} strokeWidth="2" opacity={op * 0.6} />;
        })}
        <circle cx="140" cy="140" r={pulse} fill={RED} opacity="0.12" />
        <circle cx="140" cy="140" r={pulse} fill="none" stroke={RED} strokeWidth="2" strokeDasharray="5 4" />
        <g style={{ color: SUN_C }}>
          <circle cx="140" cy="140" r="120" fill="url(#dither25o)" opacity="0.3" />
        </g>
        <g transform={`translate(140 ${140 + Math.abs(Math.sin(t * 2.5)) * -6})`}>
          <ellipse cx="0" cy="20" rx="14" ry="4" fill="rgba(0,0,0,0.25)" />
          <path d="M -14 -22 Q -14 -38 0 -38 Q 14 -38 14 -22 Q 14 -10 0 10 Q -14 -10 -14 -22 Z" fill={RED} stroke={INK} strokeWidth="3" />
          <circle cx="0" cy="-22" r="6" fill="white" stroke={INK} strokeWidth="2" />
        </g>
        <text x="140" y="20" textAnchor="middle" fontFamily={handFont} fontSize="16" fill={INK}>N</text>
        <text x="265" y="145" textAnchor="middle" fontFamily={handFont} fontSize="16" fill={INK}>E</text>
        <text x="140" y="270" textAnchor="middle" fontFamily={handFont} fontSize="16" fill={INK}>S</text>
        <text x="15" y="145" textAnchor="middle" fontFamily={handFont} fontSize="16" fill={INK}>W</text>
      </svg>
      <div style={{ marginTop: "auto", marginBottom: 70, display: "flex", flexDirection: "column", gap: 12, alignItems: "center" }}>
        <CTAButton label="📍 Use my location" color={SUN_C} w={260} seed={5} />
        <div style={{ fontFamily: labelFont, fontSize: 14, color: "#888", textDecoration: "underline" }}>or pick a place on the map</div>
      </div>
    </OBShell>
  );
}

// SCREEN 3 — discovering
function OB3() {
  const t = useTime();
  const found = Math.min(47, Math.floor(t * 8));
  const critters = [
    { Comp: Bee, ph: 0 },
    { Comp: (p) => <Bird {...p} color={BLUE} />, ph: 0.3 },
    { Comp: Frog, ph: 0.7 },
    { Comp: (p) => <Flower {...p} petal={PINK} />, ph: 1.1 },
    { Comp: Mushroom, ph: 1.5 },
    { Comp: (p) => <Bird {...p} color={ORANGE} />, ph: 1.9 },
    { Comp: (p) => <Flower {...p} petal={PURPLE} />, ph: 2.3 },
    { Comp: Bee, ph: 2.7 },
  ];
  return (
    <OBShell idx={2}>
      <div style={{ marginTop: 20, textAlign: "center" }}>
        <h1 style={{ fontFamily: handFont, fontSize: 34, color: INK, lineHeight: 1.05, transform: "rotate(-0.5deg)" }}>
          Look who's <span style={{ color: GRASS }}>nearby</span>...
        </h1>
        <p style={{ fontFamily: labelFont, fontSize: 16, color: "#5a5a5a", margin: "10px 20px 0" }}>
          Drawn from naturalists' sightings around your spot.
        </p>
      </div>
      <div style={{ position: "relative", width: 320, height: 320, marginTop: 16 }}>
        <svg width="320" height="320" viewBox="0 0 320 320" style={{ position: "absolute", inset: 0 }}>
          <defs>
            <pattern id="d3" width="4" height="4" patternUnits="userSpaceOnUse">
              <rect width="4" height="4" fill="transparent" />
              <rect x="0" y="0" width="2" height="2" fill={SUN_C} />
            </pattern>
          </defs>
          <circle cx="160" cy="160" r="140" fill="url(#d3)" opacity="0.3" />
          {critters.map((c, i) => {
            const localT = (t * 0.6 + c.ph) % 4;
            const angle = (i / critters.length) * Math.PI * 2 + t * 0.1;
            const r = 110 + Math.sin(t + i) * 10;
            const x = 160 + Math.cos(angle) * r, y = 160 + Math.sin(angle) * r;
            const visible = localT > 0.3;
            const scale = visible ? Math.min(1, (localT - 0.3) * 2) : 0;
            return (
              <g key={i} transform={`translate(${x} ${y}) scale(${scale})`} opacity={scale}>
                <g transform="translate(-22 -22)"><c.Comp size={44} /></g>
              </g>
            );
          })}
          <g transform="translate(160 160)">
            <path d={wobbleRect(-50, -38, 100, 76, 2, 7)} fill="white" stroke={INK} strokeWidth="3" />
            <text x="0" y="0" textAnchor="middle" fontFamily={handFont} fontSize="44" fill={GRASS}>{found}</text>
            <text x="0" y="22" textAnchor="middle" fontFamily={labelFont} fontSize="13" fill={INK}>species</text>
          </g>
          {[0.1, 0.4, 0.7, 1.0].map((p, i) => {
            const a = (p + t * 0.2) * Math.PI * 2;
            const x = 160 + Math.cos(a) * 90, y = 160 + Math.sin(a) * 90;
            return <Sparkle key={i} x={x} y={y} size={5 + Math.sin(t * 3 + i) * 2} color={[PINK, PURPLE, BLUE, SUN_C][i]} />;
          })}
        </svg>
      </div>
      <div style={{ marginTop: "auto", marginBottom: 70 }}>
        <CTAButton label="Meet them all →" color={GRASS} />
      </div>
    </OBShell>
  );
}

// SCREEN 4 — spirit critter
function OB4() {
  const t = useTime();
  const opts = [
    { Comp: Bee, l: "Bee", v: "pollinator", c: SUN_C },
    { Comp: (p) => <Bird {...p} color={BLUE} />, l: "Bird", v: "watcher", c: BLUE },
    { Comp: Frog, l: "Frog", v: "listener", c: GRASS },
    { Comp: (p) => <Flower {...p} petal={PINK} />, l: "Flower", v: "grower", c: PINK },
    { Comp: Mushroom, l: "Fungi", v: "decomposer", c: PURPLE },
    { Comp: (p) => <Bird {...p} color={ORANGE} />, l: "Hawk", v: "guardian", c: ORANGE },
  ];
  const selected = 0;
  return (
    <OBShell idx={3}>
      <div style={{ marginTop: 20, textAlign: "center" }}>
        <h1 style={{ fontFamily: handFont, fontSize: 34, color: INK, lineHeight: 1.05, transform: "rotate(-1deg)" }}>
          Who's your <span style={{ color: SUN_C, background: INK, padding: "0 6px" }}>spirit</span> critter?
        </h1>
        <p style={{ fontFamily: labelFont, fontSize: 15, color: "#5a5a5a", margin: "10px 20px 0" }}>
          Pick the role you'd like to play in your local web.
        </p>
      </div>
      <div style={{ marginTop: 18, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, width: "100%" }}>
        {opts.map((o, i) => {
          const wob = Math.sin(t * 1.5 + i) * 2;
          const isSel = i === selected;
          return (
            <div key={i} style={{ position: "relative", height: 110 }}>
              <svg width="100%" height="110" viewBox="0 0 100 110" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
                <path d={wobbleRect(3, 3, 94, 104, 1.5, i + 7)} fill={isSel ? o.c : "white"} fillOpacity={isSel ? 0.4 : 1} stroke={INK} strokeWidth={isSel ? "3" : "2"} />
              </svg>
              <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", paddingTop: 6 }}>
                <div style={{ transform: `rotate(${wob}deg)` }}><o.Comp size={50} /></div>
                <div style={{ fontFamily: handFont, fontSize: 18, color: INK, marginTop: 4, lineHeight: 1 }}>{o.l}</div>
                <div style={{ fontFamily: labelFont, fontSize: 11, color: "#666" }}>{o.v}</div>
              </div>
              {isSel && (
                <svg width="32" height="32" style={{ position: "absolute", top: -8, right: -6 }}>
                  <circle cx="16" cy="16" r="14" fill={INK} />
                  <text x="16" y="22" textAnchor="middle" fontSize="18" fill={SUN_C}>✓</text>
                </svg>
              )}
            </div>
          );
        })}
      </div>
      <div style={{ marginTop: "auto", marginBottom: 70 }}>
        <CTAButton label="I'm a Bee 🐝 →" color={SUN_C} />
      </div>
    </OBShell>
  );
}

// SCREEN 5 — frequency
function OB5() {
  const t = useTime();
  const opts = [
    { l: "every morning", sub: "a daily tiny update", c: SUN_C, e: "🌅" },
    { l: "weekly digest", sub: "Sundays only — the highlights", c: GRASS, e: "📬", sel: true },
    { l: "only when it matters", sub: "we'll surprise you", c: PINK, e: "✨" },
    { l: "never, just open it", sub: "no nudges", c: "#bbb", e: "🤫" },
  ];
  return (
    <OBShell idx={4}>
      <div style={{ marginTop: 20, textAlign: "center" }}>
        <h1 style={{ fontFamily: handFont, fontSize: 34, color: INK, lineHeight: 1.05, transform: "rotate(-0.5deg)" }}>
          How often should we whisper?
        </h1>
        <CrayonUnderline width={220} color={PURPLE} />
        <p style={{ fontFamily: labelFont, fontSize: 15, color: "#5a5a5a", margin: "10px 20px 0" }}>
          We'll only nudge you about real changes near you.
        </p>
      </div>
      <svg width="160" height="100" viewBox="0 0 160 100" style={{ marginTop: 14 }}>
        <g transform={`translate(0 ${Math.sin(t * 2) * 4})`}>
          <g transform="translate(48 18)"><Frog size={64} /></g>
          <g transform={`translate(${100 + Math.sin(t * 3) * 4} ${30 + Math.cos(t * 2) * 3}) rotate(${Math.sin(t * 2) * 8})`}>
            <path d="M 0 0 L 40 0 L 40 26 L 0 26 Z" fill="white" stroke={INK} strokeWidth="2" />
            <path d="M 0 0 L 20 14 L 40 0" fill="none" stroke={INK} strokeWidth="2" />
            <text x="20" y="20" textAnchor="middle" fontSize="10" fontFamily={handFont}>hi!</text>
          </g>
        </g>
      </svg>
      <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 10, width: "100%" }}>
        {opts.map((o, i) => (
          <div key={i} style={{ position: "relative", height: 64 }}>
            <svg width="100%" height="64" viewBox="0 0 360 64" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
              <path d={wobbleRect(3, 3, 354, 58, 1.5, i + 17)} fill={o.sel ? o.c : "white"} fillOpacity={o.sel ? 0.3 : 1} stroke={INK} strokeWidth={o.sel ? 3 : 2} />
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", padding: "0 16px", gap: 14 }}>
              <div style={{ fontSize: 28 }}>{o.e}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: handFont, fontSize: 20, color: INK, lineHeight: 1 }}>{o.l}</div>
                <div style={{ fontFamily: labelFont, fontSize: 12, color: "#666", marginTop: 2 }}>{o.sub}</div>
              </div>
              {o.sel && <div style={{ fontFamily: handFont, fontSize: 22, color: INK }}>✓</div>}
            </div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: "auto", marginBottom: 70 }}>
        <CTAButton label="Sounds good →" />
      </div>
    </OBShell>
  );
}

// SCREEN 6 — welcome
function OB6() {
  const t = useTime();
  return (
    <OBShell idx={5}>
      <div style={{ marginTop: 30, textAlign: "center" }}>
        <h1 style={{ fontFamily: handFont, fontSize: 40, color: INK, lineHeight: 1, transform: "rotate(-1deg)" }}>You're in the web</h1>
        <h1 style={{ fontFamily: handFont, fontSize: 40, color: INK, lineHeight: 1, marginTop: 4, transform: "rotate(1deg)" }}>now, <span style={{ color: GRASS }}>Bee</span> 🐝</h1>
        <p style={{ fontFamily: labelFont, fontSize: 16, color: "#5a5a5a", margin: "16px 30px 0", lineHeight: 1.5 }}>
          Welcome to <i>your</i> Life Web — a living portrait of the wild things sharing your neighborhood.
        </p>
      </div>
      <svg width="320" height="280" viewBox="0 0 320 280" style={{ marginTop: 6 }}>
        {Array.from({ length: 14 }).map((_, i) => {
          const a = (i / 14) * Math.PI * 2;
          const r = 110 + Math.sin(t * 2 + i) * 12;
          const x = 160 + Math.cos(a + t * 0.3) * r, y = 140 + Math.sin(a + t * 0.3) * r;
          return <Sparkle key={i} x={x} y={y} size={4 + (i % 3) * 2} color={[SUN_C, PINK, PURPLE, BLUE, ORANGE, GRASS, RED][i % 7]} />;
        })}
        <g transform={`translate(160 140) scale(${1.8 + Math.sin(t * 2) * 0.05}) rotate(${Math.sin(t) * 5})`}>
          <g transform="translate(-32 -32)"><Bee size={64} /></g>
        </g>
        <g transform={`translate(${50 + Math.sin(t) * 6} ${60 + Math.cos(t * 1.2) * 6})`}><Flower size={48} petal={PINK} /></g>
        <g transform={`translate(${230 + Math.sin(t * 1.3) * 6} ${50 + Math.cos(t) * 6})`}><Bird size={48} color={BLUE} /></g>
        <g transform={`translate(${50 + Math.sin(t * 1.1) * 6} ${200 + Math.cos(t * 0.8) * 6})`}><Mushroom size={48} /></g>
        <g transform={`translate(${230 + Math.sin(t * 0.9) * 6} ${210 + Math.cos(t * 1.1) * 6})`}><Frog size={48} /></g>
      </svg>
      <div style={{ marginTop: "auto", marginBottom: 70 }}>
        <CTAButton label="Let's explore →" color={SUN_C} w={280} />
      </div>
    </OBShell>
  );
}

// ===========================================================
// USER PROFILE
// ===========================================================
function PStat({ n, l, c }) {
  return (
    <div style={{ flex: 1, position: "relative", height: 50 }}>
      <svg width="100%" height="50" viewBox="0 0 100 50" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        <path d={wobbleRect(2, 2, 96, 46, 1, Math.floor(Math.random() * 30) + 100)} fill="white" stroke={INK} strokeWidth="2" />
      </svg>
      <div style={{ position: "absolute", inset: 0, padding: 4, textAlign: "center" }}>
        <div style={{ fontFamily: handFont, fontSize: 20, color: c, lineHeight: 1 }}>{n}</div>
        <div style={{ fontFamily: labelFont, fontSize: 10, color: "#666" }}>{l}</div>
      </div>
    </div>
  );
}

function Badge({ l, c, sub, got, e, t, idx }) {
  const wob = Math.sin(t * 0.8 + idx) * 1.5;
  return (
    <div style={{ textAlign: "center", opacity: got ? 1 : 0.5 }}>
      <div style={{ position: "relative", width: 64, height: 72, margin: "0 auto", transform: `rotate(${wob}deg)` }}>
        <svg width="64" height="72" viewBox="0 0 64 72">
          <path d="M 18 50 L 12 70 L 22 64 L 32 70 L 42 64 L 52 70 L 46 50 Z" fill={got ? c : "#ccc"} stroke={INK} strokeWidth="2" />
          <circle cx="32" cy="32" r="26" fill={got ? c : "#ddd"} stroke={INK} strokeWidth="3" />
          <circle cx="32" cy="32" r="20" fill="white" stroke={INK} strokeWidth="1.5" strokeDasharray="2 2" />
          <text x="32" y="38" textAnchor="middle" fontSize="20">{got ? e : "?"}</text>
        </svg>
      </div>
      <div style={{ fontFamily: handFont, fontSize: 14, color: INK, lineHeight: 1, marginTop: 2 }}>{l}</div>
      <div style={{ fontFamily: labelFont, fontSize: 10, color: "#777" }}>{sub}</div>
    </div>
  );
}

function ProfTabs() {
  const tabs = [
    { i: "🌍", l: "Home" }, { i: "🌿", l: "Species" },
    { i: "📡", l: "Signals" }, { i: "📜", l: "Reports" },
    { i: "🙂", l: "You" },
  ];
  return (
    <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 88 }}>
      <svg width="100%" height="88" viewBox="0 0 390 88" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        <path d={wobbleRect(4, 4, 382, 80, 2, 21)} fill="white" stroke={INK} strokeWidth="3" />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", justifyContent: "space-around", alignItems: "center", padding: "0 14px 26px" }}>
        {tabs.map((t, i) => {
          const active = i === 4;
          return (
            <div key={i} style={{ textAlign: "center", position: "relative" }}>
              <div style={{ fontSize: 24, transform: active ? "scale(1.2) rotate(-5deg)" : "none", filter: active ? "none" : "grayscale(0.4)" }}>{t.i}</div>
              <div style={{ fontFamily: labelFont, fontSize: 11, color: active ? INK : "#888", fontWeight: active ? 700 : 400 }}>{t.l}</div>
              {active && (
                <svg width="36" height="6" style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", bottom: -6 }}>
                  <path d={wobble(2, 3, 34, 3, 1, 6, 7)} stroke={SUN_C} strokeWidth="3" fill="none" strokeLinecap="round" />
                </svg>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Screen_Profile() {
  const t = useTime();
  return (
    <div style={{ width: "100%", height: "100%", position: "relative", ...paperBgStyle, overflow: "hidden" }}>
      <div style={{ position: "absolute", top: 50, left: 30, width: 80, height: 22, background: "rgba(255,210,74,0.7)", border: `1.5px solid ${INK}`, transform: "rotate(-6deg)", zIndex: 3 }} />
      <div style={{ position: "absolute", top: 56, right: 28, width: 70, height: 20, background: "rgba(245,163,199,0.7)", border: `1.5px solid ${INK}`, transform: "rotate(7deg)", zIndex: 3 }} />
      <div style={{ padding: "60px 20px 4px", position: "relative" }}>
        <div style={{ fontFamily: labelFont, fontSize: 11, color: "#888", letterSpacing: 2, textTransform: "uppercase" }}>~ Field Journal ~</div>
        <div style={{ fontFamily: handFont, fontSize: 30, color: INK, lineHeight: 1, transform: "rotate(-0.5deg)" }}>Your Naturalist Passport</div>
      </div>
      <div style={{ padding: "12px 16px 0" }}>
        <div style={{ position: "relative", padding: 14, background: "white", border: `3px solid ${INK}`, transform: "rotate(-1deg)", boxShadow: "5px 5px 0 rgba(0,0,0,0.15)" }}>
          <svg width="20" height="20" style={{ position: "absolute", top: -8, left: -8 }}><Sparkle x={10} y={10} size={8} color={SUN_C} /></svg>
          <svg width="20" height="20" style={{ position: "absolute", top: -8, right: -8 }}><Sparkle x={10} y={10} size={8} color={PINK} /></svg>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ fontFamily: labelFont, fontSize: 11, color: "#999", letterSpacing: 1, textTransform: "uppercase" }}>Naturalist №0247</div>
              <div style={{ fontFamily: handFont, fontSize: 28, color: INK, lineHeight: 1, marginTop: 2 }}>Maya Patel</div>
              <div style={{ fontFamily: labelFont, fontSize: 13, color: "#555", marginTop: 2 }}>📍 Berkeley, CA · 7 mo. afield</div>
            </div>
            <div style={{ position: "relative" }}>
              <svg width="64" height="64">
                <circle cx="32" cy="32" r="28" fill={SUN_C} stroke={INK} strokeWidth="2.5" />
                <text x="32" y="20" textAnchor="middle" fontSize="9" fontFamily={labelFont} fill={INK} fontWeight="700">SPIRIT</text>
                <text x="32" y="48" textAnchor="middle" fontSize="9" fontFamily={labelFont} fill={INK} fontWeight="700">BEE</text>
              </svg>
            </div>
          </div>
          <div style={{ marginTop: 12, position: "relative", height: 180, background: "#fff8d6", border: `2.5px solid ${INK}`, overflow: "hidden" }}>
            <svg width="100%" height="100%" viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice">
              <Cloud x={30} y={20} scale={0.8} />
              <Cloud x={240} y={30} scale={0.7} />
              <g transform={`translate(110 30) scale(1.8) rotate(${Math.sin(t) * 4} 32 36)`}><Bee size={64} /></g>
              <g transform={`translate(40 100) scale(0.7) rotate(${Math.sin(t * 1.2) * 3} 32 32)`}><Flower size={64} petal={PINK} /></g>
              <g transform={`translate(220 110) scale(0.6) rotate(${Math.sin(t * 0.9 + 1) * 3} 32 32)`}><Flower size={64} petal={PURPLE} /></g>
            </svg>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <PStat n="142" l="sightings" c={GRASS} />
            <PStat n="38" l="species" c={BLUE} />
            <PStat n="9" l="reports" c={ORANGE} />
            <PStat n="L4" l="rank" c={RED} />
          </div>
          <div style={{ marginTop: 12, padding: 8, background: "#fff8d6", border: `2px dashed ${INK}`, fontFamily: handFont, fontSize: 16, color: INK, fontStyle: "italic", textAlign: "center" }}>
            "I notice the small things." 🐝
          </div>
        </div>
      </div>
      <div style={{ padding: "16px 16px 0", display: "flex", gap: 6 }}>
        {["🏅 Badges", "📓 Field Notes", "🌐 Web"].map((l, i) => (
          <div key={i} style={{ position: "relative", flex: 1, height: 36 }}>
            <svg width="100%" height="36" viewBox="0 0 100 36" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
              <path d={wobbleRect(2, 2, 96, 32, 1.2, i + 90)} fill={i === 0 ? INK : "white"} stroke={INK} strokeWidth="2" />
            </svg>
            <div style={{ position: "relative", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: labelFont, fontSize: 13, color: i === 0 ? "white" : INK, fontWeight: 700 }}>{l}</div>
          </div>
        ))}
      </div>
      <div style={{ padding: "12px 16px 100px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
          {[
            { l: "First Find", c: SUN_C, sub: "Mar 12", got: true, e: "🥇" },
            { l: "Bee Friend", c: PINK, sub: "x10 bees", got: true, e: "🐝" },
            { l: "Early Bird", c: BLUE, sub: "before 6am", got: true, e: "🌅" },
            { l: "Civic Hero", c: ORANGE, sub: "1st report", got: true, e: "📜" },
            { l: "Rare Seeker", c: PURPLE, sub: "??? / 5", got: false, e: "🔮" },
            { l: "Sky Watcher", c: BLUE, sub: "??? / 20", got: false, e: "🦅" },
            { l: "Forest Guide", c: GRASS, sub: "??? / 50", got: false, e: "🌳" },
            { l: "Web Weaver", c: RED, sub: "??? / 100", got: false, e: "🕸️" },
          ].map((b, i) => (<Badge key={i} {...b} t={t} idx={i} />))}
        </div>
        <div style={{ marginTop: 18 }}>
          <div style={{ fontFamily: handFont, fontSize: 20, color: INK, transform: "rotate(-0.5deg)" }}>
            Path to Level 5 — <span style={{ color: PURPLE }}>Field Scout</span>
          </div>
          <div style={{ marginTop: 8, position: "relative", height: 28 }}>
            <svg width="100%" height="28" viewBox="0 0 358 28" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
              <path d={wobbleRect(3, 3, 352, 22, 1, 100)} fill="white" stroke={INK} strokeWidth="2" />
              <path d={wobbleRect(5, 5, 230, 18, 0.8, 101)} fill={PURPLE} fillOpacity="0.5" stroke={PURPLE} strokeWidth="1" />
              <g transform={`translate(${230 + Math.sin(t * 2) * 6} 14)`}><Sparkle x={0} y={0} size={6} color={SUN_C} /></g>
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: labelFont, fontSize: 12, color: INK, fontWeight: 700 }}>
              68 / 100 sightings
            </div>
          </div>
        </div>
      </div>
      <ProfTabs />
    </div>
  );
}

// ===========================================================
// HOME with live map
// ===========================================================
function Screen_Home_Live() {
  return (
    <div style={{ width: "100%", height: "100%", position: "relative", ...paperBgStyle, overflow: "hidden" }}>
      <div style={{ padding: "60px 20px 12px", position: "relative", zIndex: 2 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontFamily: handFont, fontSize: 30, color: INK, lineHeight: 1, transform: "rotate(-1deg)" }}>Your Life Web</div>
            <CrayonUnderline width={170} color={SUN_C} />
            <div style={{ fontFamily: labelFont, fontSize: 15, color: "#5a5a5a", marginTop: 6 }}>📍 Berkeley, CA · 10km</div>
          </div>
          <svg width="44" height="44">
            <path d={wobbleRect(2, 2, 40, 40, 1.5, 3)} fill="white" stroke={INK} strokeWidth="2.5" />
            <text x="22" y="29" textAnchor="middle" fontSize="20" fontFamily={handFont}>☀</text>
          </svg>
        </div>
      </div>
      <div style={{ margin: "0 16px", position: "relative" }}><LiveMap /></div>
      <div style={{ display: "flex", gap: 10, padding: "16px 16px 0" }}>
        {[{ n: 47, l: "species", c: GRASS, e: "🌱" }, { n: 12, l: "active now", c: SUN_C, e: "✨" }, { n: 3, l: "at risk", c: RED, e: "!" }].map((s, i) => (
          <div key={i} style={{ flex: 1, position: "relative", height: 80 }}>
            <svg width="100%" height="80" style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none" viewBox="0 0 110 80">
              <path d={wobbleRect(3, 3, 104, 74, 1.5, i + 2)} fill="white" stroke={INK} strokeWidth="2.5" />
            </svg>
            <div style={{ position: "absolute", inset: 0, padding: "8px 10px", boxSizing: "border-box" }}>
              <div style={{ fontFamily: handFont, fontSize: 28, color: s.c, lineHeight: 1 }}>{s.n}</div>
              <div style={{ fontFamily: labelFont, fontSize: 13, color: "#5a5a5a", marginTop: 2 }}>{s.l} {s.e}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding: "16px 16px 100px" }}>
        <div style={{ fontFamily: handFont, fontSize: 22, color: INK, transform: "rotate(-0.5deg)" }}>What's happening here</div>
        <CrayonUnderline width={200} color={PINK} />
        <div style={{ marginTop: 12, position: "relative", height: 64 }}>
          <svg width="100%" height="64" style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none" viewBox="0 0 360 64">
            <path d={wobbleRect(3, 3, 354, 58, 1.5, 13)} fill="#fff8d6" stroke={INK} strokeWidth="2.5" />
          </svg>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", padding: "0 14px", gap: 12 }}>
            <div style={{ fontSize: 28 }}>🐝</div>
            <div>
              <div style={{ fontFamily: labelFont, fontSize: 15, color: INK, fontWeight: 600 }}>Pollinators are buzzing!</div>
              <div style={{ fontFamily: labelFont, fontSize: 13, color: "#5a5a5a" }}>14 bee sightings this week</div>
            </div>
          </div>
        </div>
      </div>
      <TabBar active={0} />
    </div>
  );
}

Object.assign(window, {
  OB1, OB2, OB3, OB4, OB5, OB6,
  Screen_Profile, Screen_Home_Live,
  LiveEarth, LiveMap,
});
