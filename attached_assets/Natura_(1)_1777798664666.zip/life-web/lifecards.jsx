/* global React */
const { useState: useStateLC, useEffect: useEffectLC } = React;

const { Bee, Bird, Flower, Frog, Mushroom, Sparkle, TabBar, Cloud, Tree } = window;

const PAPER = "#fdf6e3";
const INK_C = "#1a1a1a";
const GRASS_C = "#7fc77f";
const SUN_C2 = "#ffd24a";
const RED_C = "#e25555";
const PINK_C = "#f5a3c7";
const PURPLE_C = "#a78bd9";
const ORANGE_C = "#f08a3a";
const BLUE_C = "#5b8def";

const handF = `"Caveat", "Marker Felt", cursive`;
const labelF = `"Patrick Hand", "Marker Felt", cursive`;

const paperBgLC = {
  background: `
    radial-gradient(circle at 20% 30%, rgba(180,140,100,0.07) 1px, transparent 1px),
    radial-gradient(circle at 70% 60%, rgba(180,140,100,0.06) 1px, transparent 1px),
    ${PAPER}`,
  backgroundSize: "23px 23px, 31px 31px, auto",
};

function lcWobble(x1, y1, x2, y2, intensity = 2, segments = 8, seed = 0) {
  const dx = x2 - x1, dy = y2 - y1;
  let d = `M ${x1} ${y1}`;
  for (let i = 1; i <= segments; i++) {
    const t = i / segments;
    const px = x1 + dx * t, py = y1 + dy * t;
    const r = Math.sin((seed + i) * 1.7) * intensity + Math.cos((seed + i) * 2.3) * intensity * 0.6;
    const nx = -dy / Math.hypot(dx, dy), ny = dx / Math.hypot(dx, dy);
    d += ` L ${(px + nx * r).toFixed(1)} ${(py + ny * r).toFixed(1)}`;
  }
  return d;
}
function lcWobbleRect(x, y, w, h, intensity = 1.8, seed = 1) {
  const seg = 6;
  let d = `M ${x} ${y}`;
  const sides = [[x, y, x + w, y], [x + w, y, x + w, y + h], [x + w, y + h, x, y + h], [x, y + h, x, y]];
  sides.forEach(([x1, y1, x2, y2], si) => {
    for (let i = 1; i <= seg; i++) {
      const t = i / seg;
      const px = x1 + (x2 - x1) * t, py = y1 + (y2 - y1) * t;
      const r = Math.sin((seed + si * 7 + i) * 1.7) * intensity;
      d += ` L ${(px + r).toFixed(1)} ${(py + r * 0.7).toFixed(1)}`;
    }
  });
  return d + " Z";
}
function lcWobbleCircle(cx, cy, r, intensity = 1.5, segments = 28, seed = 1) {
  let d = "";
  for (let i = 0; i <= segments; i++) {
    const a = (i / segments) * Math.PI * 2;
    const wob = Math.sin((seed + i) * 1.7) * intensity;
    const x = cx + Math.cos(a) * (r + wob);
    const y = cy + Math.sin(a) * (r + wob);
    d += (i === 0 ? "M" : "L") + ` ${x.toFixed(1)} ${y.toFixed(1)} `;
  }
  return d + " Z";
}

function CrayonU({ width = 120, color = SUN_C2 }) {
  return (
    <svg width={width} height="10" style={{ display: "block", marginTop: -2 }}>
      <path d={lcWobble(2, 5, width - 2, 6, 2, 10, 4)} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round" opacity="0.7" />
    </svg>
  );
}

function useT() {
  const [t, setT] = useStateLC(0);
  useEffectLC(() => {
    let raf, start = performance.now();
    const tick = (now) => { setT((now - start) / 1000); raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);
  return t;
}

// ============================================================
// SAMPLE iNAT-STYLE DATA
// ============================================================
const SAMPLE_CARDS = [
  {
    id: "honeybee", name: "Western Honey Bee", sci: "Apis mellifera",
    Comp: Bee, role: "Pollinator", roleColor: SUN_C2, group: "Insects",
    nearby: 142, lastSeen: "2 days ago", confidence: 92, level: 5,
    badges: ["Common", "Keystone"], unlock: "Discovery", noteCount: 14,
    monthlyActivity: [3, 8, 22, 41, 68, 89, 92, 78, 54, 28, 9, 4],
  },
  {
    id: "monarch", name: "Monarch Butterfly", sci: "Danaus plexippus",
    Comp: () => <Bee size={64} />, role: "Pollinator", roleColor: ORANGE_C, group: "Insects",
    nearby: 18, lastSeen: "12 days ago", confidence: 71, level: 3,
    badges: ["Seasonal", "Keystone"], unlock: "Activity", noteCount: 6,
    monthlyActivity: [0, 0, 2, 14, 38, 22, 12, 6, 24, 41, 8, 0],
  },
  {
    id: "redbird", name: "Northern Cardinal", sci: "Cardinalis cardinalis",
    Comp: (p) => <Bird {...p} color={RED_C} />, role: "Seed disperser", roleColor: RED_C, group: "Birds",
    nearby: 67, lastSeen: "Today", confidence: 88, level: 4,
    badges: ["Common"], unlock: "Discovery", noteCount: 9,
    monthlyActivity: [44, 51, 58, 62, 71, 65, 60, 58, 54, 49, 47, 46],
  },
  {
    id: "treefrog", name: "Pacific Tree Frog", sci: "Pseudacris regilla",
    Comp: Frog, role: "Indicator species", roleColor: GRASS_C, group: "Amphibians",
    nearby: 4, lastSeen: "3 weeks ago", confidence: 64, level: 4,
    badges: ["Rare", "Sensitive"], unlock: "Missing", noteCount: 3,
    monthlyActivity: [12, 18, 24, 22, 14, 8, 4, 2, 6, 14, 16, 14],
    sensitive: true,
  },
  {
    id: "morel", name: "Black Morel", sci: "Morchella elata",
    Comp: Mushroom, role: "Decomposer", roleColor: PURPLE_C, group: "Fungi",
    nearby: 3, lastSeen: "Last spring", confidence: 41, level: 2,
    badges: ["Seasonal", "Rare"], unlock: "Discovery", noteCount: 1,
    monthlyActivity: [0, 0, 8, 26, 12, 1, 0, 0, 0, 0, 0, 0],
  },
  {
    id: "lupine", name: "Silver Lupine", sci: "Lupinus albifrons",
    Comp: (p) => <Flower {...p} petal={PURPLE_C} />, role: "Habitat / food", roleColor: PURPLE_C, group: "Plants",
    nearby: 24, lastSeen: "1 week ago", confidence: 78, level: 3,
    badges: ["Keystone"], unlock: "Impact", noteCount: 4,
    monthlyActivity: [0, 4, 18, 38, 52, 41, 22, 8, 2, 0, 0, 0],
  },
  {
    id: "sterling", name: "European Starling", sci: "Sturnus vulgaris",
    Comp: (p) => <Bird {...p} color={"#5a5a7a"} />, role: "Generalist", roleColor: "#888", group: "Birds",
    nearby: 188, lastSeen: "Today", confidence: 95, level: 2,
    badges: ["Common"], unlock: "Discovery", noteCount: 0,
    monthlyActivity: [80, 82, 86, 92, 98, 102, 110, 114, 108, 96, 88, 82],
  },
  {
    id: "swallowtail", name: "Western Tiger Swallowtail", sci: "Papilio rutulus",
    Comp: (p) => <Bee {...p} />, role: "Pollinator", roleColor: SUN_C2, group: "Insects",
    nearby: 9, lastSeen: "Not this season", confidence: 52, level: 1,
    badges: ["Seasonal", "Missing"], unlock: "Missing", noteCount: 0,
    monthlyActivity: [0, 0, 4, 18, 32, 28, 14, 4, 0, 0, 0, 0],
  },
];

// ============================================================
// RARITY / BADGE SYSTEM — paper stamp style
// ============================================================
const BADGE_STYLES = {
  Common: { c: "#6a8a6a", e: "●", label: "Common" },
  Rare: { c: PURPLE_C, e: "✦", label: "Rare" },
  Seasonal: { c: ORANGE_C, e: "❋", label: "Seasonal" },
  Missing: { c: RED_C, e: "?", label: "Missing" },
  Keystone: { c: SUN_C2, e: "✶", label: "Keystone" },
  Sensitive: { c: "#7a7a9a", e: "◐", label: "Sensitive" },
};

function PaperStamp({ kind, small = false, idx = 0 }) {
  const s = BADGE_STYLES[kind];
  if (!s) return null;
  const w = small ? 60 : 78, h = small ? 22 : 26;
  const fs = small ? 10 : 11;
  return (
    <div style={{ position: "relative", width: w, height: h, transform: `rotate(${(idx % 2 === 0 ? -1 : 1) * 2}deg)` }}>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
        <path d={lcWobbleRect(2, 2, w - 4, h - 4, 0.8, idx + 33)} fill="white" stroke={s.c} strokeWidth="1.5" />
        <path d={lcWobbleRect(4, 4, w - 8, h - 8, 0.6, idx + 34)} fill="none" stroke={s.c} strokeWidth="0.8" strokeDasharray="2 2" opacity="0.6" />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 4, fontFamily: labelF, fontSize: fs, color: s.c, fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase" }}>
        <span style={{ fontSize: fs + 2 }}>{s.e}</span> {s.label}
      </div>
    </div>
  );
}

// ============================================================
// THE LIFE CARD — collectible component
// ============================================================
function LifeCard({ card, t, focused = false, locked = false }) {
  const lvl = card.level;
  const wob = Math.sin(t * 0.8 + (card.id.length || 1)) * 1.2;
  const glow = focused ? 0.7 + Math.sin(t * 2) * 0.3 : 0;
  const W = 168, H = 240;

  return (
    <div style={{ position: "relative", width: W, height: H, transform: `rotate(${wob}deg)`, transition: "transform 0.4s" }}>
      {focused && (
        <svg width={W + 40} height={H + 40} style={{ position: "absolute", left: -20, top: -20, pointerEvents: "none" }}>
          <path d={lcWobbleRect(8, 8, W + 24, H + 24, 3, 99)} fill="none" stroke={card.roleColor} strokeWidth="3" opacity={glow} />
        </svg>
      )}
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: "absolute", inset: 0 }}>
        <defs>
          <pattern id={`pap-${card.id}`} width="3" height="3" patternUnits="userSpaceOnUse">
            <rect width="3" height="3" fill={PAPER} />
            <circle cx="1" cy="1" r="0.4" fill="rgba(180,140,100,0.15)" />
          </pattern>
        </defs>
        <path d={lcWobbleRect(3, 3, W - 6, H - 6, 1.6, card.id.length + 5)} fill={`url(#pap-${card.id})`} stroke={INK_C} strokeWidth="2.5" />
        <path d={lcWobbleRect(7, 7, W - 14, H - 14, 1.2, card.id.length + 6)} fill="none" stroke={card.roleColor} strokeWidth="1.5" opacity="0.8" />
        {/* corner ornaments */}
        {[[12, 12], [W - 12, 12], [12, H - 12], [W - 12, H - 12]].map(([x, y], i) => (
          <g key={i} transform={`translate(${x} ${y})`}>
            <path d={`M -4 0 L 4 0 M 0 -4 L 0 4`} stroke={card.roleColor} strokeWidth="1.5" />
          </g>
        ))}
      </svg>
      {/* Card content */}
      <div style={{ position: "absolute", inset: 0, padding: 12, display: "flex", flexDirection: "column", filter: locked ? "grayscale(1) brightness(0.7)" : "none", opacity: locked ? 0.5 : 1 }}>
        {/* header — group + level */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", fontFamily: labelF, fontSize: 9, color: "#7a6a4a", letterSpacing: 1, textTransform: "uppercase" }}>
          <span>{card.group}</span>
          <span>L{lvl}/5</span>
        </div>
        {/* portrait — circular with dither halo */}
        <div style={{ marginTop: 4, position: "relative", height: 84, display: "flex", justifyContent: "center" }}>
          <svg width="92" height="92" viewBox="0 0 92 92" style={{ position: "absolute", left: "50%", transform: "translateX(-50%)" }}>
            <defs>
              <pattern id={`d-${card.id}`} width="3" height="3" patternUnits="userSpaceOnUse">
                <rect width="3" height="3" fill="transparent" />
                <rect x="0" y="0" width="1.5" height="1.5" fill={card.roleColor} />
              </pattern>
            </defs>
            <path d={lcWobbleCircle(46, 46, 40, 1.2, 30, card.id.length + 8)} fill={`url(#d-${card.id})`} opacity="0.45" />
            <path d={lcWobbleCircle(46, 46, 36, 1, 28, card.id.length + 9)} fill="white" stroke={INK_C} strokeWidth="2" />
          </svg>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ transform: `scale(${1 + Math.sin(t * 1.2 + card.name.length) * 0.04})` }}>
              {locked ? (
                <div style={{ fontFamily: handF, fontSize: 48, color: "#666" }}>?</div>
              ) : (
                <card.Comp size={56} />
              )}
            </div>
          </div>
          {!locked && lvl >= 3 && (
            <svg width="14" height="14" style={{ position: "absolute", top: 8, right: 22 }}>
              <Sparkle x={7} y={7} size={4} color={SUN_C2} />
            </svg>
          )}
        </div>
        {/* name */}
        <div style={{ marginTop: 4, textAlign: "center", lineHeight: 1 }}>
          <div style={{ fontFamily: handF, fontSize: 18, color: INK_C }}>{locked ? "—— ——" : card.name}</div>
          <div style={{ fontFamily: labelF, fontSize: 10, color: "#7a6a4a", fontStyle: "italic", marginTop: 2 }}>{locked ? "" : card.sci}</div>
        </div>
        {/* role chip */}
        <div style={{ marginTop: 6, display: "flex", justifyContent: "center" }}>
          <div style={{ position: "relative", padding: "2px 10px" }}>
            <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none" viewBox="0 0 100 22">
              <path d={lcWobbleRect(2, 2, 96, 18, 0.8, 41)} fill={card.roleColor} fillOpacity="0.18" stroke={card.roleColor} strokeWidth="1.5" />
            </svg>
            <span style={{ position: "relative", fontFamily: labelF, fontSize: 11, color: card.roleColor, fontWeight: 700 }}>{locked ? "??? role" : card.role}</span>
          </div>
        </div>
        {/* progress dots */}
        <div style={{ marginTop: 8, display: "flex", justifyContent: "center", gap: 4 }}>
          {[1, 2, 3, 4, 5].map((i) => (
            <svg key={i} width="10" height="10">
              <circle cx="5" cy="5" r="3.5" fill={i <= lvl ? card.roleColor : "transparent"} stroke={INK_C} strokeWidth="1.2" />
            </svg>
          ))}
        </div>
        {/* footer stats */}
        <div style={{ marginTop: "auto", display: "flex", justifyContent: "space-between", fontFamily: labelF, fontSize: 10, color: INK_C, padding: "0 2px" }}>
          <div>
            <div style={{ fontSize: 16, fontFamily: handF, lineHeight: 1, color: card.roleColor }}>{locked ? "?" : card.nearby}</div>
            <div style={{ fontSize: 9, color: "#7a6a4a" }}>nearby</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 12, fontFamily: handF, lineHeight: 1, color: INK_C }}>{locked ? "—" : card.lastSeen}</div>
            <div style={{ fontSize: 9, color: "#7a6a4a" }}>last seen</div>
          </div>
        </div>
        {/* badges */}
        {!locked && card.badges.length > 0 && (
          <div style={{ position: "absolute", top: -8, right: -6, display: "flex", flexDirection: "column", gap: 4 }}>
            {card.badges.slice(0, 2).map((b, i) => (
              <PaperStamp key={i} kind={b} small idx={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// SCREEN: COLLECTION GRID
// ============================================================
function Screen_LifeCards() {
  const t = useT();
  const [filter, setFilter] = useStateLC("All");
  const filters = ["All", "Birds", "Insects", "Plants", "Amphibians", "Fungi", "Missing", "Keystone", "Rare"];

  const visible = filter === "All" ? SAMPLE_CARDS :
    SAMPLE_CARDS.filter(c => c.group === filter || c.badges.includes(filter));

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", ...paperBgLC, overflow: "auto", paddingBottom: 100 }}>
      {/* header */}
      <div style={{ padding: "60px 20px 4px", position: "relative" }}>
        <div style={{ fontFamily: labelF, fontSize: 11, color: "#888", letterSpacing: 2, textTransform: "uppercase" }}>~ Local Field Collection ~</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            <h1 style={{ fontFamily: handF, fontSize: 32, color: INK_C, margin: 0, lineHeight: 1, transform: "rotate(-1deg)" }}>Life Cards</h1>
            <CrayonU width={140} color={SUN_C2} />
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: handF, fontSize: 26, color: GRASS_C, lineHeight: 1 }}>38 / 142</div>
            <div style={{ fontFamily: labelF, fontSize: 11, color: "#7a6a4a" }}>collected nearby</div>
          </div>
        </div>
      </div>

      {/* search bar */}
      <div style={{ padding: "14px 16px 0", position: "relative" }}>
        <div style={{ position: "relative", height: 42 }}>
          <svg width="100%" height="42" viewBox="0 0 358 42" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
            <path d={lcWobbleRect(3, 3, 352, 36, 1.5, 67)} fill="white" stroke={INK_C} strokeWidth="2" />
          </svg>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", padding: "0 14px", gap: 10, fontFamily: labelF, fontSize: 14, color: "#888" }}>
            <span style={{ fontSize: 18 }}>🔍</span>
            <span>search by common or scientific name…</span>
          </div>
        </div>
      </div>

      {/* filter pills */}
      <div style={{ padding: "12px 16px 4px", display: "flex", gap: 6, overflowX: "auto" }}>
        {filters.map((f, i) => {
          const active = f === filter;
          return (
            <div key={f} onClick={() => setFilter(f)} style={{ position: "relative", height: 30, flexShrink: 0, cursor: "pointer" }}>
              <svg width={f.length * 8 + 28} height="30" viewBox={`0 0 ${f.length * 8 + 28} 30`} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
                <path d={lcWobbleRect(2, 2, f.length * 8 + 24, 26, 1, i + 50)} fill={active ? INK_C : "white"} stroke={INK_C} strokeWidth="1.8" />
              </svg>
              <div style={{ position: "relative", height: "100%", display: "flex", alignItems: "center", padding: "0 14px", fontFamily: labelF, fontSize: 13, color: active ? PAPER : INK_C, fontWeight: 700 }}>{f}</div>
            </div>
          );
        })}
      </div>

      {/* "Today near you" daily hook */}
      <div style={{ padding: "14px 16px 0" }}>
        <div style={{ position: "relative" }}>
          <svg width="100%" height="92" viewBox="0 0 358 92" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
            <path d={lcWobbleRect(3, 3, 352, 86, 2, 71)} fill="#fff8d6" stroke={INK_C} strokeWidth="2.5" />
            <path d={lcWobbleRect(7, 7, 344, 78, 1.5, 72)} fill="none" stroke={SUN_C2} strokeWidth="1.5" strokeDasharray="3 3" />
          </svg>
          <div style={{ position: "relative", padding: "12px 14px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div style={{ fontFamily: handF, fontSize: 18, color: INK_C, lineHeight: 1, transform: "rotate(-0.5deg)" }}>Today near you</div>
              <div style={{ fontFamily: labelF, fontSize: 10, color: "#7a6a4a", letterSpacing: 1, textTransform: "uppercase" }}>📅 Tue</div>
            </div>
            <div style={{ marginTop: 8, display: "flex", gap: 12 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ transform: `rotate(${Math.sin(t * 2) * 6}deg)` }}><Bee size={28} /></div>
                <div>
                  <div style={{ fontFamily: handF, fontSize: 14, color: INK_C, lineHeight: 1 }}>2 active</div>
                  <div style={{ fontFamily: labelF, fontSize: 10, color: GRASS_C }}>new sightings</div>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Frog size={28} />
                <div>
                  <div style={{ fontFamily: handF, fontSize: 14, color: INK_C, lineHeight: 1 }}>1 missing</div>
                  <div style={{ fontFamily: labelF, fontSize: 10, color: RED_C }}>not seen lately</div>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <Mushroom size={28} />
                <div>
                  <div style={{ fontFamily: handF, fontSize: 14, color: INK_C, lineHeight: 1 }}>3 new</div>
                  <div style={{ fontFamily: labelF, fontSize: 10, color: PURPLE_C }}>can unlock</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION: Your Local Collection */}
      <div style={{ padding: "20px 16px 0" }}>
        <SectionHeader title="Your Local Collection" sub="cards earned near you" color={GRASS_C} />
        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, justifyItems: "center" }}>
          {SAMPLE_CARDS.slice(0, 4).map((c, i) => (
            <div key={c.id} style={{ animation: `fadeIn 0.4s ${i * 0.08}s both` }}>
              <LifeCard card={c} t={t} />
            </div>
          ))}
        </div>
      </div>

      {/* SECTION: New Near You */}
      <div style={{ padding: "28px 16px 0" }}>
        <SectionHeader title="New Near You" sub="recent activity — tap to unlock" color={ORANGE_C} pulse />
        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, justifyItems: "center" }}>
          {[SAMPLE_CARDS[6], SAMPLE_CARDS[5]].map((c, i) => (
            <div key={c.id} style={{ position: "relative" }}>
              <LifeCard card={c} t={t} locked />
              <svg width="56" height="32" style={{ position: "absolute", top: -4, left: -10, transform: "rotate(-12deg)" }}>
                <path d={lcWobbleRect(2, 2, 52, 28, 1, 88)} fill={ORANGE_C} stroke={INK_C} strokeWidth="2" />
                <text x="28" y="20" textAnchor="middle" fontFamily={labelF} fontSize="11" fill={PAPER} fontWeight="700">NEW</text>
              </svg>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION: Missing */}
      <div style={{ padding: "28px 16px 0" }}>
        <SectionHeader title="Missing Cards" sub="historically here, not seen recently" color={RED_C} />
        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, justifyItems: "center" }}>
          {[SAMPLE_CARDS[3], SAMPLE_CARDS[7]].map((c) => (
            <div key={c.id}><LifeCard card={c} t={t} /></div>
          ))}
        </div>
      </div>

      {/* SECTION: Keystone */}
      <div style={{ padding: "28px 16px 0" }}>
        <SectionHeader title="Keystone Species" sub="critical to your local web" color={SUN_C2} />
        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, justifyItems: "center" }}>
          {SAMPLE_CARDS.filter(c => c.badges.includes("Keystone")).slice(0, 2).map((c) => (
            <div key={c.id}><LifeCard card={c} t={t} /></div>
          ))}
        </div>
      </div>

      <div style={{ padding: "24px 20px", textAlign: "center", fontFamily: labelF, fontSize: 11, color: "#999", lineHeight: 1.4 }}>
        Based on community-science observations. <br />Missing observations don't always mean absent.
      </div>

      <style>{`@keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }`}</style>

      <TabBar active={1} />
    </div>
  );
}

function SectionHeader({ title, sub, color, pulse = false }) {
  const t = useT();
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
      <div>
        <div style={{ fontFamily: handF, fontSize: 22, color: INK_C, lineHeight: 1, transform: "rotate(-0.5deg)" }}>{title}</div>
        <div style={{ fontFamily: labelF, fontSize: 12, color: "#7a6a4a", marginTop: 2 }}>{sub}</div>
      </div>
      {pulse && (
        <svg width="14" height="14">
          <circle cx="7" cy="7" r={4 + Math.sin(t * 3) * 2} fill={color} opacity={0.5 + Math.sin(t * 3) * 0.4} />
          <circle cx="7" cy="7" r="3" fill={color} />
        </svg>
      )}
      <svg width="60" height="6" style={{ position: "absolute", marginLeft: -1, marginTop: 26 }}>
        <path d={lcWobble(0, 3, 60, 3, 1.2, 8, title.length)} stroke={color} strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.7" />
      </svg>
    </div>
  );
}

// ============================================================
// SCREEN: SINGLE CARD DETAIL — expanded view
// ============================================================
function Screen_CardDetail({ cardIdx = 0 }) {
  const t = useT();
  const card = SAMPLE_CARDS[cardIdx];
  const maxAct = Math.max(...card.monthlyActivity);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", background: `linear-gradient(180deg, #1a2030 0%, #2a3045 60%, #1a2030 100%)`, overflow: "auto", paddingBottom: 100 }}>
      {/* sparkles bg */}
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, pointerEvents: "none" }} viewBox="0 0 390 844" preserveAspectRatio="none">
        {Array.from({ length: 24 }).map((_, i) => {
          const x = (i * 47) % 390;
          const y = (i * 71) % 844;
          const op = 0.3 + Math.sin(t * 1.5 + i) * 0.3;
          return <circle key={i} cx={x} cy={y} r={1 + (i % 3) * 0.5} fill="white" opacity={op} />;
        })}
      </svg>

      {/* header */}
      <div style={{ padding: "60px 20px 0", display: "flex", justifyContent: "space-between", alignItems: "center", position: "relative" }}>
        <div style={{ fontFamily: handF, fontSize: 18, color: "rgba(255,255,255,0.7)" }}>← back</div>
        <div style={{ fontFamily: labelF, fontSize: 11, color: "rgba(255,255,255,0.5)", letterSpacing: 2, textTransform: "uppercase" }}>Life Card</div>
        <div style={{ fontFamily: handF, fontSize: 18, color: "rgba(255,255,255,0.7)" }}>⤴</div>
      </div>

      {/* THE CARD — premium presentation */}
      <div style={{ padding: "20px 0", display: "flex", justifyContent: "center", position: "relative" }}>
        <div style={{ transform: `rotate(${Math.sin(t * 0.6) * 1.5}deg) scale(1.15)` }}>
          <LifeCard card={card} t={t} focused />
        </div>
        {[0, 1, 2, 3].map(i => {
          const a = (i / 4) * Math.PI * 2 + t * 0.5;
          return (
            <svg key={i} width="20" height="20" style={{ position: "absolute", left: `${50 + Math.cos(a) * 28}%`, top: `${50 + Math.sin(a) * 32}%`, pointerEvents: "none" }}>
              <Sparkle x={10} y={10} size={5 + Math.sin(t * 2 + i) * 2} color={[SUN_C2, PINK_C, BLUE_C, PURPLE_C][i]} />
            </svg>
          );
        })}
      </div>

      {/* badges row */}
      <div style={{ padding: "0 20px", display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
        {card.badges.map((b, i) => <PaperStamp key={i} kind={b} idx={i} />)}
      </div>

      {/* paper card with details — peeking up from dark bg */}
      <div style={{ marginTop: 22, marginLeft: 12, marginRight: 12, padding: "18px 16px", borderRadius: 4, position: "relative", ...paperBgLC, boxShadow: "0 -10px 40px rgba(0,0,0,0.4)" }}>
        <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, pointerEvents: "none" }} preserveAspectRatio="none" viewBox="0 0 358 600">
          <path d={lcWobbleRect(2, 2, 354, 596, 2, 99)} fill="none" stroke={INK_C} strokeWidth="2" />
        </svg>

        {/* tabs */}
        <div style={{ display: "flex", gap: 6, position: "relative" }}>
          {["Story", "Activity", "Impact"].map((tb, i) => (
            <div key={tb} style={{ flex: 1, position: "relative", height: 30 }}>
              <svg width="100%" height="30" viewBox="0 0 100 30" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
                <path d={lcWobbleRect(2, 2, 96, 26, 1, i + 110)} fill={i === 0 ? INK_C : "white"} stroke={INK_C} strokeWidth="1.8" />
              </svg>
              <div style={{ position: "relative", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: labelF, fontSize: 12, fontWeight: 700, color: i === 0 ? PAPER : INK_C }}>{tb}</div>
            </div>
          ))}
        </div>

        {/* Why this matters */}
        <div style={{ marginTop: 16, position: "relative" }}>
          <div style={{ fontFamily: handF, fontSize: 20, color: INK_C, lineHeight: 1, transform: "rotate(-0.3deg)" }}>Why she matters</div>
          <div style={{ fontFamily: labelF, fontSize: 14, color: "#3a3a3a", marginTop: 6, lineHeight: 1.5 }}>
            One in three bites of food you eat is here because of her work. She and her sisters pollinate the wildflowers, fruit trees, and crops in your neighborhood — quietly, daily, and mostly unnoticed.
          </div>
        </div>

        {/* Seasonal activity chart */}
        <div style={{ marginTop: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
            <div style={{ fontFamily: handF, fontSize: 18, color: INK_C, lineHeight: 1 }}>Activity through the year</div>
            <div style={{ fontFamily: labelF, fontSize: 11, color: "#888" }}>obs / month</div>
          </div>
          <CrayonU width={220} color={card.roleColor} />
          <div style={{ marginTop: 12, position: "relative", height: 100 }}>
            <svg width="100%" height="100" viewBox="0 0 326 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
              {/* baseline */}
              <path d={lcWobble(8, 88, 320, 88, 0.6, 24, 121)} stroke={INK_C} strokeWidth="1.2" fill="none" />
              {card.monthlyActivity.map((v, i) => {
                const x = 14 + i * 26;
                const h = (v / maxAct) * 76;
                const cur = i === 6;
                return (
                  <g key={i}>
                    <path d={lcWobbleRect(x, 88 - h, 18, h, 0.7, i + 130)} fill={cur ? card.roleColor : `${card.roleColor}55`} stroke={INK_C} strokeWidth="1.2" />
                    <text x={x + 9} y="98" textAnchor="middle" fontFamily={labelF} fontSize="8" fill="#666">{["J","F","M","A","M","J","J","A","S","O","N","D"][i]}</text>
                  </g>
                );
              })}
              {/* "you are here" arrow */}
              <g transform="translate(175 16)">
                <text fontFamily={handF} fontSize="13" fill={INK_C}>now ↓</text>
              </g>
            </svg>
          </div>
        </div>

        {/* Local timeline */}
        <div style={{ marginTop: 18 }}>
          <div style={{ fontFamily: handF, fontSize: 18, color: INK_C, lineHeight: 1 }}>Your local timeline</div>
          <div style={{ marginTop: 8, position: "relative", paddingLeft: 24 }}>
            <svg width="3" height="180" style={{ position: "absolute", left: 8, top: 6 }}>
              <path d="M 1.5 0 L 1.5 180" stroke={INK_C} strokeWidth="1.5" strokeDasharray="3 3" />
            </svg>
            {[
              { d: "2 days ago", e: "🐝", c: SUN_C2, l: "Last seen at Live Oak Park" },
              { d: "1 week ago", e: "✦", c: GRASS_C, l: "Activity peaked — 14 obs" },
              { d: "Mar 12", e: "🥇", c: ORANGE_C, l: "You discovered her", y: true },
              { d: "Last summer", e: "📊", c: PURPLE_C, l: "Baseline established" },
            ].map((item, i) => (
              <div key={i} style={{ marginBottom: 10, position: "relative" }}>
                <svg width="20" height="20" style={{ position: "absolute", left: -22, top: 0 }}>
                  <circle cx="10" cy="10" r="9" fill={item.c} stroke={INK_C} strokeWidth="1.5" />
                  <text x="10" y="14" textAnchor="middle" fontSize="11">{item.e}</text>
                </svg>
                <div style={{ fontFamily: labelF, fontSize: 11, color: "#888" }}>{item.d}</div>
                <div style={{ fontFamily: labelF, fontSize: 14, color: INK_C, fontWeight: item.y ? 700 : 400 }}>{item.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* confidence / data caveat */}
        <div style={{ marginTop: 14, position: "relative", padding: 12 }}>
          <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none" viewBox="0 0 326 80">
            <path d={lcWobbleRect(2, 2, 322, 76, 1.5, 155)} fill="rgba(167,139,217,0.1)" stroke={PURPLE_C} strokeWidth="1.5" strokeDasharray="3 2" />
          </svg>
          <div style={{ position: "relative" }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div style={{ fontFamily: handF, fontSize: 16, color: INK_C, lineHeight: 1 }}>Data confidence</div>
              <div style={{ fontFamily: handF, fontSize: 22, color: PURPLE_C, lineHeight: 1 }}>{card.confidence}%</div>
            </div>
            <div style={{ marginTop: 6, height: 8, position: "relative" }}>
              <svg width="100%" height="8" viewBox="0 0 300 8" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
                <path d={lcWobbleRect(1, 1, 298, 6, 0.5, 156)} fill="white" stroke={INK_C} strokeWidth="1" />
                <path d={lcWobbleRect(2, 2, (card.confidence / 100) * 296, 4, 0.4, 157)} fill={PURPLE_C} />
              </svg>
            </div>
            <div style={{ fontFamily: labelF, fontSize: 11, color: "#666", marginTop: 8, lineHeight: 1.4 }}>
              Based on {card.nearby} observations · {card.noteCount} unique observers · research-grade ratio.
              Missing observations don't always mean a species is absent.
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div style={{ marginTop: 18, display: "flex", flexDirection: "column", gap: 10 }}>
          <ActionButton label="See Impact Cascade →" color={card.roleColor} sub="what changes if she disappears?" />
          {card.level >= 5 ? (
            <ActionButton label="Generate Civic Report" color={ORANGE_C} sub="prefilled with iNat data" icon="📜" />
          ) : (
            <ActionLockedButton label={`Unlock report at L${card.level + 1}`} color="#aaa" />
          )}
          <ActionButton label="Share this card" color={INK_C} sub="without precise location" icon="↗" textColor={PAPER} />
        </div>

        {/* respect note */}
        <div style={{ marginTop: 16, fontFamily: labelF, fontSize: 11, color: "#888", textAlign: "center", fontStyle: "italic", lineHeight: 1.4 }}>
          Observe respectfully. Don't disturb wildlife or<br />enter restricted areas.
        </div>
      </div>
    </div>
  );
}

function ActionButton({ label, color, sub, icon, textColor = "white" }) {
  return (
    <div style={{ position: "relative", height: 56 }}>
      <svg width="100%" height="56" viewBox="0 0 326 56" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        <path d={lcWobbleRect(3, 3, 320, 50, 1.5, color.length + 200)} fill={color} stroke={INK_C} strokeWidth="2.5" />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", padding: "0 16px", gap: 12 }}>
        {icon && <div style={{ fontSize: 22 }}>{icon}</div>}
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: handF, fontSize: 18, color: textColor, lineHeight: 1 }}>{label}</div>
          {sub && <div style={{ fontFamily: labelF, fontSize: 11, color: textColor, opacity: 0.85, marginTop: 1 }}>{sub}</div>}
        </div>
      </div>
    </div>
  );
}
function ActionLockedButton({ label, color }) {
  return (
    <div style={{ position: "relative", height: 48, opacity: 0.6 }}>
      <svg width="100%" height="48" viewBox="0 0 326 48" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
        <path d={lcWobbleRect(3, 3, 320, 42, 1, 220)} fill="white" stroke={color} strokeWidth="2" strokeDasharray="4 3" />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, fontFamily: labelF, fontSize: 14, color: "#888", fontWeight: 700 }}>
        🔒 {label}
      </div>
    </div>
  );
}

// ============================================================
// SCREEN: UNLOCK MOMENT
// ============================================================
function Screen_Unlock() {
  const t = useT();
  const card = SAMPLE_CARDS[0];
  // moment freezes early; sparkles continue
  const phase = Math.min(1, t * 0.6);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", background: `radial-gradient(ellipse at center, #2a4030 0%, #0e1a14 80%)`, overflow: "hidden", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
      {/* radial light beams */}
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, pointerEvents: "none" }} viewBox="0 0 390 844" preserveAspectRatio="none">
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2 + t * 0.05;
          const x2 = 195 + Math.cos(a) * 600, y2 = 422 + Math.sin(a) * 600;
          return <line key={i} x1="195" y1="422" x2={x2} y2={y2} stroke="rgba(255,210,74,0.08)" strokeWidth="80" />;
        })}
      </svg>
      {/* sparkles */}
      <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, pointerEvents: "none" }} viewBox="0 0 390 844" preserveAspectRatio="none">
        {Array.from({ length: 30 }).map((_, i) => {
          const a = (i / 30) * Math.PI * 2 + (i % 3);
          const r = 100 + ((i * 37) % 220);
          const tt = (t * 1.5 + i * 0.3) % 4;
          const x = 195 + Math.cos(a + tt * 0.2) * r;
          const y = 422 + Math.sin(a + tt * 0.2) * r;
          return <Sparkle key={i} x={x} y={y} size={3 + (i % 3) * 2} color={[SUN_C2, PINK_C, BLUE_C, PURPLE_C, "white"][i % 5]} />;
        })}
      </svg>

      {/* announcement */}
      <div style={{ textAlign: "center", marginBottom: 30, opacity: phase, transform: `translateY(${(1 - phase) * 20}px)`, position: "relative" }}>
        <div style={{ fontFamily: labelF, fontSize: 12, color: "rgba(255,210,74,0.8)", letterSpacing: 4, textTransform: "uppercase" }}>~ a new card joins your web ~</div>
        <h1 style={{ fontFamily: handF, fontSize: 36, color: "white", margin: "8px 0 0", lineHeight: 1, transform: "rotate(-0.5deg)", textShadow: "0 2px 12px rgba(255,210,74,0.5)" }}>
          New species <span style={{ color: SUN_C2 }}>discovered</span>
        </h1>
        <div style={{ fontFamily: handF, fontSize: 22, color: "rgba(255,255,255,0.85)", marginTop: 4 }}>near you.</div>
      </div>

      {/* the card — entrance scale */}
      <div style={{ position: "relative", transform: `scale(${0.4 + phase * 0.85}) rotate(${(1 - phase) * 30}deg)`, opacity: phase }}>
        <LifeCard card={card} t={t} focused />
        {/* burst rays */}
        <svg width="400" height="400" style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%, -50%)", pointerEvents: "none", opacity: 1 - phase * 0.5 }}>
          {Array.from({ length: 16 }).map((_, i) => {
            const a = (i / 16) * Math.PI * 2;
            const x1 = 200 + Math.cos(a) * 110, y1 = 200 + Math.sin(a) * 110;
            const x2 = 200 + Math.cos(a) * (130 + Math.sin(t * 4 + i) * 12);
            const y2 = 200 + Math.sin(a) * (130 + Math.sin(t * 4 + i) * 12);
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={SUN_C2} strokeWidth="2" strokeLinecap="round" />;
          })}
        </svg>
      </div>

      {/* progression note */}
      <div style={{ marginTop: 28, textAlign: "center", opacity: phase }}>
        <div style={{ fontFamily: handF, fontSize: 24, color: "white", lineHeight: 1 }}>Western Honey Bee</div>
        <div style={{ fontFamily: labelF, fontSize: 13, color: "rgba(255,255,255,0.6)", fontStyle: "italic", marginTop: 2 }}>Apis mellifera</div>
        <div style={{ marginTop: 12, display: "flex", justifyContent: "center", gap: 6 }}>
          {[1, 2, 3, 4, 5].map(i => (
            <svg key={i} width="14" height="14">
              <circle cx="7" cy="7" r="5" fill={i === 1 ? SUN_C2 : "transparent"} stroke="white" strokeWidth="1.5" />
            </svg>
          ))}
        </div>
        <div style={{ fontFamily: labelF, fontSize: 11, color: "rgba(255,255,255,0.5)", marginTop: 6, letterSpacing: 1, textTransform: "uppercase" }}>Level 1 · Seen</div>
      </div>

      {/* CTAs */}
      <div style={{ position: "absolute", bottom: 50, left: 0, right: 0, padding: "0 28px", display: "flex", flexDirection: "column", gap: 10, opacity: phase }}>
        <div style={{ position: "relative", height: 56 }}>
          <svg width="100%" height="56" viewBox="0 0 334 56" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
            <path d={lcWobbleRect(3, 3, 328, 50, 1.5, 300)} fill={SUN_C2} stroke={INK_C} strokeWidth="2.5" />
          </svg>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: handF, fontSize: 22, color: INK_C }}>
            Meet your new neighbor →
          </div>
        </div>
        <div style={{ textAlign: "center", fontFamily: labelF, fontSize: 13, color: "rgba(255,255,255,0.6)", textDecoration: "underline" }}>add to collection · keep exploring</div>
      </div>
    </div>
  );
}

// ============================================================
// SCREEN: SENSITIVE SPECIES — protected variant
// ============================================================
function Screen_Sensitive() {
  const t = useT();
  const card = SAMPLE_CARDS[3]; // tree frog (sensitive)

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", ...paperBgLC, overflow: "auto", paddingBottom: 100 }}>
      <div style={{ padding: "60px 20px 4px" }}>
        <div style={{ fontFamily: labelF, fontSize: 11, color: "#888", letterSpacing: 2, textTransform: "uppercase" }}>← Life Cards · Sensitive</div>
        <div style={{ fontFamily: handF, fontSize: 28, color: INK_C, lineHeight: 1, transform: "rotate(-0.5deg)", marginTop: 4 }}>Protected card</div>
        <CrayonU width={150} color="#7a7a9a" />
      </div>

      {/* the card with overlay */}
      <div style={{ marginTop: 18, display: "flex", justifyContent: "center", position: "relative" }}>
        <div style={{ transform: "scale(1.15)" }}><LifeCard card={card} t={t} /></div>
      </div>

      {/* protected notice */}
      <div style={{ marginTop: 24, padding: "0 20px" }}>
        <div style={{ position: "relative", padding: "16px 16px" }}>
          <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }} preserveAspectRatio="none" viewBox="0 0 350 180">
            <path d={lcWobbleRect(3, 3, 344, 174, 2, 400)} fill="#f3eeff" stroke="#7a7a9a" strokeWidth="2" />
          </svg>
          <div style={{ position: "relative" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <svg width="36" height="36">
                <circle cx="18" cy="18" r="16" fill="#7a7a9a" stroke={INK_C} strokeWidth="2" />
                <text x="18" y="24" textAnchor="middle" fontSize="18" fill="white">◐</text>
              </svg>
              <div style={{ fontFamily: handF, fontSize: 22, color: INK_C, lineHeight: 1 }}>This species is sensitive</div>
            </div>
            <div style={{ marginTop: 10, fontFamily: labelF, fontSize: 14, color: "#3a3a3a", lineHeight: 1.5 }}>
              We hide precise locations for species at risk of poaching, harassment, or habitat damage. You'll see <i>region-level</i> presence only — never the exact spot.
            </div>
            <div style={{ marginTop: 10, fontFamily: labelF, fontSize: 13, color: "#5a5a7a", lineHeight: 1.4 }}>
              ✓ Generalized to your county · 10 km radius<br />
              ✓ Reports won't include precise coordinates<br />
              ✓ Shareable cards omit location entirely
            </div>
          </div>
        </div>
      </div>

      {/* fuzzy region map */}
      <div style={{ marginTop: 18, padding: "0 20px" }}>
        <div style={{ fontFamily: handF, fontSize: 18, color: INK_C, lineHeight: 1 }}>Where she lives</div>
        <div style={{ fontFamily: labelF, fontSize: 11, color: "#888", marginTop: 2 }}>generalized to county · 10 km cells</div>
        <div style={{ marginTop: 10, position: "relative", height: 200 }}>
          <svg width="100%" height="200" viewBox="0 0 350 200" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
            <path d={lcWobbleRect(3, 3, 344, 194, 2, 500)} fill="#e8f4d6" stroke={INK_C} strokeWidth="2.5" />
            {/* fuzzy presence cells */}
            {[[80, 60, 0.4], [140, 80, 0.7], [200, 70, 0.5], [110, 130, 0.3], [180, 140, 0.6], [240, 110, 0.4]].map(([x, y, op], i) => (
              <g key={i}>
                <path d={lcWobbleRect(x, y, 50, 32, 1.5, i + 600)} fill="#7a7a9a" fillOpacity={op} stroke="#7a7a9a" strokeWidth="1.5" strokeDasharray="2 2" />
              </g>
            ))}
            <text x="175" y="190" textAnchor="middle" fontFamily={labelF} fontSize="11" fill="#5a5a7a" fontStyle="italic">~ presence likely in shaded areas ~</text>
          </svg>
        </div>
      </div>

      {/* awareness CTA */}
      <div style={{ marginTop: 22, padding: "0 20px" }}>
        <ActionButton label="Create awareness report" color={ORANGE_C} sub="no precise location included" icon="📜" />
      </div>

      <div style={{ padding: "20px 24px", fontFamily: labelF, fontSize: 11, color: "#888", textAlign: "center", lineHeight: 1.5 }}>
        Sensitive species protections follow iNaturalist's geoprivacy rules. <br />Observe quietly. Never share exact locations.
      </div>
    </div>
  );
}

Object.assign(window, {
  Screen_LifeCards,
  Screen_CardDetail,
  Screen_Unlock,
  Screen_Sensitive,
  LifeCard,
  PaperStamp,
  SAMPLE_CARDS,
});
